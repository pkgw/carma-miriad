char F2C_version[] = "20090411";
char xxxvers[] = "\n@(#) FORTRAN 77 to C Translator, VERSION 20090411\n";
